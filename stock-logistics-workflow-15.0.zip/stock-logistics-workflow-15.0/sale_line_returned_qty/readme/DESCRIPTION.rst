This module adds the returned quantity of sale order lines as a computed field.
