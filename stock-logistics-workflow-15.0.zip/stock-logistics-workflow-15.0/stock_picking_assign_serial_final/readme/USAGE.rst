To use this module you need to:

#. Go to a *Product > Inventory tab*.
#. Set a tracking serial option for this product.
#. Go to *Inventory > Incoming* and create one.
#. Click on generate serial number button on stock move line.
#. Fill initial S/N and final S/N to compute S/N numbers to generate a lot.
