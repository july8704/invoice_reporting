This module extends the functionality of stock module to allow assign serial numbers
from an initial S/N until last S/N for incoming pickings.
