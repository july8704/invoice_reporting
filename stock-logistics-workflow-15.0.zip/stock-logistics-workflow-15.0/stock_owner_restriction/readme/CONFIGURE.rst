To configure this module you need to:

#. Make sure to select the consignment option in inventory settings by going
   to *Inventory > Configuration > Settings* and ticking *Consignment* under
   *Traceability*.
#. Go to *Inventory > Configuration > Operation Types*.
#. Select an operation type, or create a new one, and set *Owner Restriction*
   field to the desired value.
