This module extends the functionality of stock module to allow restriction
of product quantities (quants) for stock operations such as reserve quantities
or product quantity available info.
