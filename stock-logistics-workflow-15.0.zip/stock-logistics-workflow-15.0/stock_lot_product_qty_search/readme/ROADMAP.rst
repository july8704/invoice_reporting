Ideally, this module will be deprecated once Odoo provides such a function in the core.
