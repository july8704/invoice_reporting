This module adds a search function on the Quantity (`product_qty`) field
of Lot/Serial Numbers (`stock.production.lot`) model, in order to search
on this field and provide a filter for records having a quantity on hand.
