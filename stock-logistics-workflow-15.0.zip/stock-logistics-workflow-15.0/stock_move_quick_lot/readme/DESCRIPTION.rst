This module allows to set pack operation Lot Name and End of Life Date directly
on picking operations
