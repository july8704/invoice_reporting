To configure this module, you need to:

#. Activate "Track lots or serial numbers" in Inventory -> Configuration ->
   Setting -> Lots and Serial Numbers
#. Note: the product must have "Tracking | By Lots" in the inventory tab
