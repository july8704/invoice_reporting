To use this module, you need to:

#. Go to Inventory > Operations > Transfers
#. Select a Ready picking or create it and click on Mark as Todo
#. Set Lot Name in Operations tab
#. Set optionally the end of life date in the proper column
#. When the picking will be transferred, the lot will be created with that
   name and date.
