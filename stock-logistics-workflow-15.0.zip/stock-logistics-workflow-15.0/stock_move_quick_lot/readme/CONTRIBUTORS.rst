* `Tecnativa <https://www.tecnativa.com>`_:

    * Carlos Dauden <carlos.dauden@tecnativa.com>
    * Sergio Teruel <sergio.teruel@tecnativa.com>

* `Ecosoft <http://ecosoft.co.th>`_:

    * Kitti Upariphutthiphong <kittiu@ecosoft.co.th>
    * Pimolnat Suntian <pimolnats@ecosoft.co.th>
