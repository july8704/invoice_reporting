This module adds a link between purchases, pickings and invoices as well as
on the lines. Invoices are generated from purchase orders. With this module,
you can find back which deliveries an invoice relates to.

This module improves **stock_picking_invoice_link** module by linking
purchases, pickings and invoices.
