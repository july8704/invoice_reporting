* `Tecnativa <https://www.tecnativa.com>`_

  * Vicent Cubells
  * Ernesto Tejeda
  * Pedro M. Baeza
  * Carlos Roca
  * Stefan Ungureanu

* `Obertix <https://www.obertix.net>`_

  * Vicent Cubells <vicent@vcubells.net>

* `Solvos <https://www.solvos.es>`_

  * David Alonso <david.alonso@solvos.es>
