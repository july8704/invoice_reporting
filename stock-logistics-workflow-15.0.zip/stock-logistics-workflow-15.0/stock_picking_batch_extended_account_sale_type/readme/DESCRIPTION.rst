This module extends stock_picking_batch_extended_account module to allow to set
auto invoice from batch picking in sale order type.
