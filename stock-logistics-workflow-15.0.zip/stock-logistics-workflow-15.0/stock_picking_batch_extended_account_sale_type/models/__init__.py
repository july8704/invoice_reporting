# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import res_partner
from . import sale_order_type
from . import stock_batch_picking
