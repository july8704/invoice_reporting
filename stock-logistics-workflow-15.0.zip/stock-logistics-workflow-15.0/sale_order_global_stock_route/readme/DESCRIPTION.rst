This module adds the possibility to apply a general route on a quotation.
