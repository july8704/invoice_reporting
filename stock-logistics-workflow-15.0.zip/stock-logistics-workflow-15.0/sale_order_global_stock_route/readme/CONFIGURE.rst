To use this module you have to activate the option Settings > Inventory
> Warehouse > Multi-Step Routes
