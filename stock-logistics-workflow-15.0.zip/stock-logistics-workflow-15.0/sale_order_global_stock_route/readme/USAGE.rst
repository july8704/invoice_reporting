To use this module, you simply need to:

#. Create a new quotation.
#. Add the products that you need.
#. Change the form route option.
