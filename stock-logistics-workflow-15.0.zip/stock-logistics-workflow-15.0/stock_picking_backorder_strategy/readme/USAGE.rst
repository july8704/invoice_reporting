To configure this module, you need to:

* Define backorder strategy on picking type (Warehouse > Configuration > Types of Operation)
