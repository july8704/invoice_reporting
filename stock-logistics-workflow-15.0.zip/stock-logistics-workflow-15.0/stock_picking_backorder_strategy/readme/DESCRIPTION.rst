In types of operation add a backorder strategy to be able to cancel created
backorder or to avoid to create a backorder.

Possible strategies are:

* Manual (Default): Let the backorder wizard to be launched as usual
* Create: Backorder is created if it exists some remaining quantities
* No Create: no backorder are created
* Cancel: backorder is cancelled
