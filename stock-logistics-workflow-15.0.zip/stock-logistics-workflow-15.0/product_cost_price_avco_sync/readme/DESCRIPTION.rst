This module allows to sync cost price products with average cost method from
stock moves price unit.
