#. Go to *Inventory > Operations > Batch Transfers*

   * Go to Detailed Operations or Operations page
   * Click button to fill quantity done
