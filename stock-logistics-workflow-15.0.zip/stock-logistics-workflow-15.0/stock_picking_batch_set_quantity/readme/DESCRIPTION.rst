This module extends batch transfers to add buttons to set all reserved
quantity in quantity done fields.
