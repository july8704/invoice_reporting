Auto-install module needed to correctly compute the returned quantity of sale
order lines for Kit BoM products.
