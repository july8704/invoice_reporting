#. Go to Inventory > Configuration > Shipping methods
#. Create a record with Allow create landed cost lines option checked.
#. Go to Purchase > Orders > Requests for Quotation.
#. Create an order with 2 lines: storable product + service product (landed cost).
#. Set Custom carrier.
#. Confirm Order.
#. Receives products and done picking.
#. Go to Inventory > Operations > Landed Costs.
#. A record related to the delivery purchase order lines and a cost line was created with the shipping price.
#. Landed Cost will be validated when linked purchase picking are done.
