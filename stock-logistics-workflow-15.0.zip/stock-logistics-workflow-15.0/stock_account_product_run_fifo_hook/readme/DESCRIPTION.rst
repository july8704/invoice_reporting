This module adds hook points in product_product._run_fifo in order
to add more flexibility in the information that is stored in the fifo
candidates.
