#. Add dependency of this module
#. Inherit from 'product.product'
#. Change the _run_fifo_prepare_candidate_update function in order to
   return an updated logic.
