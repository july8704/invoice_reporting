To change the source location of one or several stock moves of a picking, go to
a specific picking and click ont the button Change Source Location.
You will have three options:

* Change All moves (the source location of all stock moves will be changed)
* Change only moves with matched OLD location (you need to provide a source location and only those moves
  with the same source location will be updated)
* Select moves to change (you will need to select the moves to update)

Once the option has been selected, choose the new source location and click Apply.
