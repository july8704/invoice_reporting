This module allows you to change the source location of stock moves from the picking
