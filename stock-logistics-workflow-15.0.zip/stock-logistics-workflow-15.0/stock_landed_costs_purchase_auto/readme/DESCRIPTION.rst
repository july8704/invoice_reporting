This addon will auto-create a stock landed cost linked to the purchase order when it is
confirmed.
