#. Go to Purchase> Orders > Requests for Quotation.
#. Create an order with any product.
#. Confirm Order.
#. Go to "Receipt" smart-button.
#. Validate picking.
#. Go to Inventory > Operations > Landed Costs.
#. There will be a record related to the purchase order and the validated picking.
