To use this module you need to:

#. Go to a *Product > Inventory tab*.
#. Set a tracking option for this product.
#. Set auto create lot.
#. Go to *Inventory > Incoming* and create one.
#. Validate picking without lot.
