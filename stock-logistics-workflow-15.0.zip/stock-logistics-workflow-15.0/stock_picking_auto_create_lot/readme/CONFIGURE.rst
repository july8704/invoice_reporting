To configure this module, you need to:

#. Go to a *Inventory > Configuration > Operation Types*.
#. Set 'auto create lot' option for this operation type.

#. Go to a *Inventory > Master Data > Products*.
#. Set 'auto create lot' option for the products you need.
