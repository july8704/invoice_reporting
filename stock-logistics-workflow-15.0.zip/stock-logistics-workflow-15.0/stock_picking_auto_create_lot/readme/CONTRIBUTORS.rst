* Carlos Dauden <carlos.dauden@tecnativa.com>
* Sergio Teruel <sergio.teruel@tecnativa.com>
* Pimolnat Suntian <pimolnats@ecosoft.co.th>
* Denis Roussel <denis.roussel@acsone.eu>
* Valentin Vinagre <valentin.vinagre@sygel.es>
