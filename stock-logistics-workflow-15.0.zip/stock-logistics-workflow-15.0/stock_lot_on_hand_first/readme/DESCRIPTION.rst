This module allows to display lots with a quantity on hand as first results
in the selection field of Detailed Operations (`stock.move.line`) in order
to avoid displaying old lots that are not in stock anymore.
