On the Operations types (`stock.picking.type`) an extra checkbox will appear if
Use Existing Lots/Serial Numbers is selected, to allow reordering the results
appearing in the selection.
