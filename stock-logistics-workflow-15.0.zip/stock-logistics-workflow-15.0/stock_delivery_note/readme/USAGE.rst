In the Stock Picking form, go to the 'Additional Info' tab.
Fill in the delivery note field
Print the Delivery Slip
