This module adds a delivery note in stock pickings. This field will be displayed on delivery reports.
