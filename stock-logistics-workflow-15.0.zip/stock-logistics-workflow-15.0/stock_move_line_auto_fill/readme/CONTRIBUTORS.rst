* Zakaria Makrelouf (ACSONE SA/NV) <z.makrelouf@gmail.com>
* Luis Triana (Jarsa Sistemas de S.A. de C.V.) <luis.triana@jarsa.com.mx>
* `Tecnativa <https://www.tecnativa.com>`_:
    * Pedro M. Baeza <pedro.baeza@tecnativa.com>
    * Vicent Cubells <vicent.cubells@tecnativa.com>
    * Sergio Teruel <sergio.teruel@tecnativa.com>
    * David Vidal <david.vidal@tecnativa.com>
* Jaime Arroyo (Creu Blanca) <jaime.arroyo@creublanca.es>
* Iván Todorovich <ivan.todorovich@gmail.com>
