#. Go to *Settings* > Users and companies > Users.
#. Select one user or create a new one.
#. Select on the section "Inventory", line "Landend costs", the option "User".
