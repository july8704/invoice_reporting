#. Go to Users.
#. Select Landing costs -> User.
#. Go to *Landed Costs*.
#. This user can create and validate any landed cost.
