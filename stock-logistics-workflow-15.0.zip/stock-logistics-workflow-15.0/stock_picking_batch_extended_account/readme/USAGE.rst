To use this module, you need to:

#. Go to *Inventory > Batch Picking*.
#. Create a new batch and add some pickings such that their partners
   have the option 'Batch picking auto invoice' checked
   (See configuration section). Make sure the selected pickings are
   linked to a sales order.
#. Confirm the batch.
#. Set the batch to 'done' state. After that, invoices will be generated
   for all sales orders linked to the pickings of the batch.
#. Click on 'Print Invoices' button in the status bar and you will see a PDF
   report for all the generated invoices.
