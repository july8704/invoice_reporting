This module extends the functionality of stock_picking_batch_extended
to support the creation of invoices automatically when a batch is set
to 'Done' state and to allow you to print the invoices of the
sales orders linked to the pickings of the batch.
