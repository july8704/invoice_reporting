To configure this module, you need to check 'Batch picking auto invoice'
field of the partners for whom you want the invoice to be automatically
generated when any batch that has a 'Picking' to which they belong is
set to 'done' state.

#. Go to each of thoes partner, edit them, find 'Batch picking auto invoice'
   field under 'Sales & Purchase' tab and check it.
