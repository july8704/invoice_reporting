This module displays the Customer Reference in the pickings from Sale Order.
It also allows you to filter and search for this new field.
