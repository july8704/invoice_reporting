* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Ana Juaristi <anajuaristi@avanzosc.es>
* Mikel Arregi <mikelarregi@avanzosc.es>
* Alfredo de la Fuente <alfredodelafuente@avanzosc.es>
* David Vidal <david.vidal@tecnativa.com>
* Andreas Dian Sukarno Putro <andreasdian777@gmail.com>
* Ruchir Shukla <ruchir@bizzappdev.com>
* Divya Modi <divya.modi@bizzappdev.com>
