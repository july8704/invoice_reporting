from . import test_stock_picking_customer_ref
