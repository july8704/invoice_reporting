To configure this module, you need to:

#. Go to a *Inventory > Configuration > Settings*.
#. Choose the product field which yo want to search products.
#. Choose the file column index where product reference is stored.
#. Choose the file column index where serial number reference is stored.
