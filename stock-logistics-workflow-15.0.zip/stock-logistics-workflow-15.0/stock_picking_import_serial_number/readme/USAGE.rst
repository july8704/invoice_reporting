To use this module you need to:

#. Go to *Inventory > Incoming* and create one.
#. Click on button "Import S/N".
#. Select an excel file.
#. Click on import button.
