To use this module:

#. Go to an open picking or a scrap with products that are tracked by lots.
#. When you enter detailed operations you will notice that the lots available
   to select are filtered by the origin of the operation.
