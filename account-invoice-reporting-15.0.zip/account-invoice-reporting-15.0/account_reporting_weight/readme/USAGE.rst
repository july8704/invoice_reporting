#. Go to *Invoicing > Reporting > Management > Invoice Analysis*.
#. Add the "Weight" measure from your "Measures" dropdown in your analysis.
