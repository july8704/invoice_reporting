You need to be at least "Accountant" on "Accounting & Finance" role for
seeing the report.
