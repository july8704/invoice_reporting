This module adds the measure "Weight" in the invoices analysis view.
