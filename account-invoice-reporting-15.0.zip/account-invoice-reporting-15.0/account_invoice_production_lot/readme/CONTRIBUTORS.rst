* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
* Alessio Gerace <alessio.gerace@agilebg.com>
* Alex Comba <alex.comba@agilebg.com>
* `Tecnativa <https://www.tecnativa.com>`__:

  * Vicent Cubells
  * Pedro M. Baeza
  * Sergio Teruel
