Adds comments on invoices.
The comments can be edited directly on the invoices or loaded from
templates.

Two positions are available for the comments:

- before invoice lines
- after invoice lines
