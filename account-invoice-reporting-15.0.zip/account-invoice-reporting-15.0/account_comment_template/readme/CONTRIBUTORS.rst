* Xavier Jimenez <xavier.jimenez@qubiq.es>
* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Simone Rubino <simone.rubino@agilebg.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * Víctor Martínez

* `DynApps <https://www.dynapps.be>`_:

  * Raf Ven <raf.ven@dynapps.be>

* `Druidoo <https://www.druidoo.io>`_:

  * Iván Todorovich <ivan.todorovich@druidoo.io>

* `Jarsa <https://www.jarsa.com>`_:

  * Alan Ramos <alan.ramos@jarsa.com>
