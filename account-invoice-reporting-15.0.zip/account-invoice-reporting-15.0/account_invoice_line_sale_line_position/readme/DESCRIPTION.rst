This module is build on top of the module `sale_order_line_position`.

It adds (if any) the sale line position on the invoice line.
There can be multiple positions for one invoicing line. And they are
added to the report.
