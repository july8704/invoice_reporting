This module extends the functionality of 'Account Invoice Grouped by Picking'
module to allow you to to print correctly invoices with picking info
when there are mrp kits in them.
