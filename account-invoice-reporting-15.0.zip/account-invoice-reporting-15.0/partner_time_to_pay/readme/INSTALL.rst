Your preferred way to install addons will work with Partner Time to Pay.

An easy way to install it with all its dependencies is using pip:

* ``pip install --pre odoo11-addon-partner_time_to_pay odoo-autodiscover``
* then restart Odoo, update the addons list in your database, and install
  the Partner Time to Pay application.
