* Ray Carnes <rcarnes@ursainfosystems.com>
* Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
* Bhavesh Odedra <bodedra@opensourceintegrators.com>
* Sandip Mangukiya <smangukiya@opensourceintegrators.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* Jevin Dement <jdement@opensourceintegrators.com>
* Rafael Blasco (https://www.moduon.team/)
* Eduardo de Miguel (https://www.moduon.team/)
