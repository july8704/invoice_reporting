This module displays statistics related to the receivables and payables behavior of a partner on the *Sales & Purchases* tab of the partner form view.
Also displays the full reconcile payment date on invoices.
Statistics on each contact corresponds to the partner and its child contacts.
