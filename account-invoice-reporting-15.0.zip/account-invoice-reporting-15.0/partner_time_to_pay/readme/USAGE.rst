* Go to the *Sales & Purchases* tab of a partner
* There are 6 new fields named *AVG Days to Payable/Receivable*.
  These fields represent the average days to pay/receive for last year (LY),
  this year (YTD) and since the first invoice (lifetime).
* Adds a new field in the tree and form invoices views to check the
  Full Reconcile Payment Date
