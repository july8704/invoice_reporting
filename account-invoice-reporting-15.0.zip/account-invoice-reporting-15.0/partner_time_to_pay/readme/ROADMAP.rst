The partner_time_to_pay `roadmap <https://github.com/OCA/account-invoice-reporting/issues?q=is%3Aopen+is%3Aissue+label%3Aenhancement>`_
and `known issues <https://github.com/OCA/account-invoice-reporting/issues?q=is%3Aopen+is%3Aissue+label%3Abug>`_ can
be found on GitHub.
