This module adds the measure "Volume" in the invoices analysis view.
