#. Go to *Invoicing > Reporting > Management > Invoices*.
#. Add the "Volume" measure from your "Measures" dropdown in your analysis.
