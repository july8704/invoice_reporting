#. Create several quotation orders and confirm them.
#. Deliver pickings related to each sale order.
#. Go to *Sales > To Invoice > Orders to Invoice* and invoice these sale
   orders.
#. Open invoice newly created and print it.
#. Invoice report will group invoice lines and show information about sales
   and pickings in every group.
