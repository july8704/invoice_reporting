* `Tecnativa <https://www.tecnativa.com>`__:

  * Carlos Dauden
  * David Vidal
  * Pedro M. Baeza
  * Sergio Teruel
  * João Marques
  * Carlos Roca

* `Studio73 <https://www.studio73.es>`__:

  * Ioan Galan <ioan@studio73.es>
