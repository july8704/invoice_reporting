This module allows print invoices with picking info. This module groups
invoice lines and shows information related to sales and pickings on every
group.

It also groups under the same block those service lines that are not in the
picking, but belongs to the same sales order as the rest of the lines of the
picking.
