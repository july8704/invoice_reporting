To use this module, you need to:

#. Have the "Show Full Accounting Features" option activated for your user.
#. Go to Invoicing > Reporting > Management > Invoice Lines
