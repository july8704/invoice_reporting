To use this module, you need to:

#. Go to **Invoicing > Configuration > Invoicing > Payment Terms**. You must
   install **account_invoicing** module and set *Billing* permission to your
   user in order to be able to access to this menu.
#. Select or create a payment term with multiple term lines.
#. Go to **Invoicing > Customers > Invoices**.
#. Select or create an invoice and set payment term to invoice in the field "Due Date".
#. You can see now Due Dates.
#. Print invoice.
#. Look Due Date.
