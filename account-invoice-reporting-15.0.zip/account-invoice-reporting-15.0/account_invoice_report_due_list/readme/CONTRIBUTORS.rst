* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Vicent Cubells
  * Víctor Martínez
* `Solvos <https://www.solvos.es>`_:

  * David Alonso
