This module extends the invoice report for adding information about the
payments.
