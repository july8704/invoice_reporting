To use this module, you need to:

#. Go to **Invoicing > Customer Invoices**.
#. Select or create an validated invoice.
#. Click on button "Add credit note".
#. Select Cancel or Modify option and click on button "Add credit note".
#. Print invoice.
#. Look payment info referenced to credit note.
